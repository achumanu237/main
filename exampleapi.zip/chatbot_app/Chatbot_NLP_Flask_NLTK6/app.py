from flask import Flask, render_template, request, jsonify
import torch
import json
from nltk_utils import tokenize, bag_of_words
from model import NeuralNet

app = Flask(__name__)

# Load trained model
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
FILE = "data.pth"
data = torch.load(FILE, map_location=device)

input_size = data["input_size"]
hidden_size = data["hidden_size"]
output_size = data["output_size"]
all_words = data['all_words']
tags = data['tags']
model_state = data["model_state"]

model = NeuralNet(input_size, hidden_size, output_size).to(device)
model.load_state_dict(model_state)
model.eval()

# Load intents for responses
with open('intents.json', 'r') as f:
    intents = json.load(f)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    try:
        user_message = request.json['message']
        
        # Tokenize and create bag of words
        sentence = tokenize(user_message)
        X = bag_of_words(sentence, all_words)
        X = X.reshape(1, -1)
        X = torch.from_numpy(X).to(device)
        
        # Get prediction
        output = model(X)
        _, predicted = torch.max(output, dim=1)
        tag = tags[predicted.item()]
        
        # Get probability
        probs = torch.softmax(output, dim=1)
        prob = probs[0][predicted.item()]
        
        if prob.item() > 0.75:
            for intent in intents['intents']:
                if tag == intent["tag"]:
                    response = intent['responses'][0]  # You can randomize this
                    return jsonify({'response': response})
        else:
            return jsonify({'response': "I'm not sure I understand. Could you rephrase?"})
            
    except Exception as e:
        return jsonify({'response': f"Error: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(debug=True)