import os
from flask import Flask, render_template, request
from azure.identity import DefaultAzureCredential, get_bearer_token_provider
from openai import AzureOpenAI

app = Flask(__name__)

# Initialize the Azure OpenAI client securely
token_provider = get_bearer_token_provider(
    DefaultAzureCredential(), "https://cognitiveservices.azure.com/.default"
)
client = AzureOpenAI(
    api_version="2023-03-15-preview",  #"2024-10-21",
    azure_endpoint="https://your-endpoint.openai.azure.com/",#os.getenv("AZURE_OPENAI_ENDPOINT"),
    azure_ad_token_provider=token_provider,
    #base_url="https://YOUR-RESOURCE-NAME.openai.azure.com/openai/v1/",
    #api_key=token_provider,
)

@app.route('/', methods=['GET', 'POST'])
def index():
    response = None
    if request.method == 'POST':
        user_message = request.form.get('message')
        if user_message:
            try:
                # Call the Azure OpenAI API
                completion = client.chat.completions.create(
                    model="gpt-4o-mini", # Your deployment name
                    messages=[{"role": "user", "content": user_message}]
                )
                response = completion.choices[0].message.content
            except Exception as e:
                response = f"Error: {e}"
    return render_template('index.html', response=response)

if __name__ == '__main__':
    app.run()