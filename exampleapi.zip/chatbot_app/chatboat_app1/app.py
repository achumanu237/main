#1. First, create requirements.txt: txt Flask==2.3.3
#2. Create the main Flask application app.py:

from flask import Flask, render_template, request, jsonify
import re
import random
from datetime import datetime

app = Flask(__name__)

# Simple rule-based chatbot logic
class ChatBot:
    def __init__(self):
        self.responses = {
            'greeting': [
                'Hello! How can I help you today?',
                'Hi there! What can I do for you?',
                'Hey! Nice to meet you!'
            ],
            'farewell': [
                'Goodbye! Have a great day!',
                'See you later!',
                'Take care!'
            ],
            'name': [
                'My name is FlaskBot! I\'m your friendly chatbot.',
                'I\'m FlaskBot, created with Python and Flask!'
            ],
            'help': [
                'I can answer basic questions about the weather, time, or just chat with you!',
                'I\'m here to help! Ask me about the time, weather, or just say hello.'
            ],
            'weather': [
                'I\'m not connected to a weather service, but I hope it\'s nice outside!',
                'I wish I could tell you the weather, but you might want to check a weather app!'
            ],
            'time': [
                f'The current time is {datetime.now().strftime("%I:%M %p")}',
                f'It\'s {datetime.now().strftime("%I:%M %p")} right now!'
            ],
            'default': [
                'That\'s interesting! Tell me more.',
                'I\'m not sure I understand. Could you rephrase that?',
                'Hmm, I\'m still learning. Can you ask something else?'
            ]
        }
        
        self.patterns = {
            'greeting': r'\b(hi|hello|hey|greetings|good morning|good afternoon|good evening)\b',
            'farewell': r'\b(bye|goodbye|see you|talk to you later|farewell)\b',
            'name': r'\b(your name|who are you|what are you)\b',
            'help': r'\b(help|support|assist|what can you do)\b',
            'weather': r'\b(weather|temperature|rain|sunny|cloudy)\b',
            'time': r'\b(time|clock|hour|minute)\b'
        }

    def get_response(self, user_input):
        user_input = user_input.lower()
        
        # Check each pattern
        for intent, pattern in self.patterns.items():
            if re.search(pattern, user_input):
                return random.choice(self.responses[intent])
        
        # Default response if no pattern matches
        return random.choice(self.responses['default'])

# Initialize chatbot
chatbot = ChatBot()

@app.route('/')
def index():
    return render_template('index.html',datetime=datetime)

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message', '')
    
    # Get bot response
    bot_response = chatbot.get_response(user_message)
    
    return jsonify({
        'response': bot_response,
        'timestamp': datetime.now().strftime('%H:%M')
    })

if __name__ == '__main__':
    app.run(debug=True)