"""Below is a complete, runnable example for Option 1 (direct integration), 
which is simpler if both apps are in Python/Flask.
Example: Integrating a Chatbot into an Existing Flask App"""

from flask import Flask, request, jsonify, render_template
import random

app = Flask(__name__)

# -------------------------
# Chatbot Logic
# -------------------------
def chatbot_response(user_input: str) -> str:
    """
    Simple chatbot logic (replace with your AI model or API call).
    """
    user_input = user_input.lower().strip()
    if "hello" in user_input:
        return "Hi there! How can I help you today?"
    elif "bye" in user_input:
        return "Goodbye! Have a great day!"
    else:
        responses = [
            "I'm not sure I understand. Could you rephrase?",
            "Interesting! Tell me more.",
            "Let's talk about something else."
        ]
        return random.choice(responses)

# -------------------------
# Main App Routes
# -------------------------
@app.route("/")
def home():
    return render_template("index.html")  # Chat UI

@app.route("/chat", methods=["POST"])
def chat():
    try:
        data = request.get_json()
        if not data or "message" not in data:
            return jsonify({"error": "Invalid request"}), 400
        
        user_message = data["message"]
        bot_reply = chatbot_response(user_message)
        return jsonify({"reply": bot_reply})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# -------------------------
# Other Existing App Routes
# -------------------------
@app.route("/about")
def about():
    return "This is the About page of the main Flask app."

if __name__ == "__main__":
    app.run(debug=True)