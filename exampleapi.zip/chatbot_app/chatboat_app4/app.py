# app.py
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from openai import OpenAI
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()
# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for frontend access

# Set your OpenAI API key (use environment variable for security)
#openai.api_key = os.getenv("OPENAI_API_KEY", "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")
client = OpenAI(
    # defaults to os.environ.get("OPENAI_API_KEY")
    api_key=os.getenv("OPENAI_API_KEY"),
)

# In-memory storage for conversation history (use database in production)
conversations = {}

@app.route('/')
def index():
    """Serve the chat interface"""
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    """Handle chat messages"""
    try:
        data = request.json
        user_message = data.get('message', '')
        user_id = data.get('user_id', 'default_user')
        
        # Get or create conversation history for this user
        if user_id not in conversations:
            conversations[user_id] = []
        
        # Add user message to history
        conversations[user_id].append({"role": "user", "content": user_message})
        
        # Keep only last 10 messages to manage token usage
        if len(conversations[user_id]) > 10:
            conversations[user_id] = conversations[user_id][-10:]
        
        # Call OpenAI API
        response = client.chat.completions.create(#openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                *conversations[user_id]
            ],
            max_tokens=150,
            temperature=0.7
        )
        
        bot_response = response.choices[0].message.content
        
        # Add bot response to history
        conversations[user_id].append({"role": "assistant", "content": bot_response})
        
        return jsonify({
            'response': bot_response,
            'status': 'success'
        })
        
    except Exception as e:
        return jsonify({
            'response': f'Error: {str(e)}',
            'status': 'error'
        }), 500

@app.route('/history/<user_id>', methods=['GET'])
def get_history(user_id):
    """Retrieve conversation history for a user"""
    history = conversations.get(user_id, [])
    return jsonify({'history': history})

if __name__ == '__main__':
    app.run(debug=True, port=5000)