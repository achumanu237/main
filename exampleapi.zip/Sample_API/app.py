#Example 1: Simple REST API with CRUD Operations
# app.py
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# In-memory database (use real database in production)
items = [
    {"id": 1, "name": "Item 1", "price": 10.99},
    {"id": 2, "name": "Item 2", "price": 20.99},
    {"id": 3, "name": "Item 3", "price": 30.99}
]

# Home route
@app.route('/')
def home():
    return jsonify({
        "message": "Welcome to Flask API",
        "endpoints": {
            "GET /api/items": "Get all items",
            "GET /api/items/<id>": "Get specific item",
            "POST /api/items": "Create new item",
            "PUT /api/items/<id>": "Update item",
            "DELETE /api/items/<id>": "Delete item"
        }
    })

# GET all items
@app.route('/api/items', methods=['GET'])
def get_items():
    return jsonify({
        "status": "success",
        "data": items
    })

# GET single item
@app.route('/api/items/<int:item_id>', methods=['GET'])
def get_item(item_id):
    item = next((item for item in items if item["id"] == item_id), None)
    if item:
        return jsonify({
            "status": "success",
            "data": item
        })
    return jsonify({
        "status": "error",
        "message": "Item not found"
    }), 404

# POST create new item
@app.route('/api/items', methods=['POST'])
def create_item():
    data = request.get_json()
    
    # Validate input
    if not data or not data.get('name') or not data.get('price'):
        return jsonify({
            "status": "error",
            "message": "Name and price are required"
        }), 400
    
    # Create new item
    new_item = {
        "id": len(items) + 1,
        "name": data['name'],
        "price": data['price']
    }
    items.append(new_item)
    
    return jsonify({
        "status": "success",
        "data": new_item
    }), 201

# PUT update item
@app.route('/api/items/<int:item_id>', methods=['PUT'])
def update_item(item_id):
    item = next((item for item in items if item["id"] == item_id), None)
    
    if not item:
        return jsonify({
            "status": "error",
            "message": "Item not found"
        }), 404
    
    data = request.get_json()
    item['name'] = data.get('name', item['name'])
    item['price'] = data.get('price', item['price'])
    
    return jsonify({
        "status": "success",
        "data": item
    })

# DELETE item
@app.route('/api/items/<int:item_id>', methods=['DELETE'])
def delete_item(item_id):
    global items
    item = next((item for item in items if item["id"] == item_id), None)
    
    if not item:
        return jsonify({
            "status": "error",
            "message": "Item not found"
        }), 404
    
    items = [item for item in items if item["id"] != item_id]
    
    return jsonify({
        "status": "success",
        "message": "Item deleted"
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)