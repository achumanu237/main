#Building an API in Python
#2. Using FastAPI

# FastAPI is a modern framework known for its speed and automatic documentation.

# Steps:

# Install FastAPI and Uvicorn Run the following commands:

# pip install fastapi uvicorn[standard]

from fastapi import FastAPI
app = FastAPI()
# Sample data
users = [{"id": 1, "name": "John Doe"}, {"id": 2, "name": "Jane Doe"}]
# GET endpoint
@app.get("/users")
def get_users():
   return users
# POST endpoint
@app.post("/users")
def add_user(user: dict):
   users.append(user)
   return user

#Run the Server Start the server with Uvicorn:

#uvicorn main:app --reload