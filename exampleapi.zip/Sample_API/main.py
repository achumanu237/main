from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List

# Create FastAPI app instance
app = FastAPI(title="Sample API", description="A simple REST API with FastAPI", version="1.0")

# Data model for request body
class Item(BaseModel):
    id: int
    name: str
    price: float

# In-memory "database"
items_db: List[Item] = []

@app.get("/")
def read_root():
    """Root endpoint"""
    return {"message": "Welcome to the API!"}

@app.get("/items", response_model=List[Item])
def get_items():
    """Get all items"""
    return items_db

@app.get("/items/{item_id}", response_model=Item)
def get_item(item_id: int):
    """Get a single item by ID"""
    for item in items_db:
        if item.id == item_id:
            return item
    raise HTTPException(status_code=404, detail="Item not found")

@app.post("/items", response_model=Item)
def create_item(item: Item):
    """Create a new item"""
    # Check for duplicate ID
    if any(existing.id == item.id for existing in items_db):
        raise HTTPException(status_code=400, detail="Item with this ID already exists")
    items_db.append(item)
    return item

@app.delete("/items/{item_id}")
def delete_item(item_id: int):
    """Delete an item by ID"""
    for index, item in enumerate(items_db):
        if item.id == item_id:
            del items_db[index]
            return {"message": "Item deleted successfully"}
    raise HTTPException(status_code=404, detail="Item not found")