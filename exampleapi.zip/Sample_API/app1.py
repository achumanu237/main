#Building an API in Python
#1. Using Flask
from flask import Flask, jsonify, request

app = Flask(__name__)

# Sample data
users = [{"id": 1, "name": "John Doe"}, {"id": 2, "name": "Jane Doe"}]

# GET endpoint
@app.route('/users', methods=['GET'])
def get_users():
    return jsonify(users)

# POST endpoint
@app.route('/users', methods=['POST'])
def add_user():
    new_user = request.get_json()
    users.append(new_user)
    return jsonify(new_user), 201

if __name__ == '__main__':
    app.run(debug=True)